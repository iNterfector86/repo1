Alerts				-	Waarschuwingen
Designators			-	Aanwijzers
Dialog_StatReports		-	Dialoog_StatRapportages
Dialog_Trees			-	Dialoog_Bomen
Dialogs_Various			-	Dialogen_Willekeurig
GameplayCommands		-	SpelCommandos
Incidents			-	Incidenten
ITabs				-	Itap
Letters				-	Brieven
MainTabs			-	BasisTappen
Messages			-	Berichten
Misc_Gameplay			-	Overig_Speelspel

