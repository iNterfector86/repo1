Adjectives		-	Bijvoeglijk naamwoorden
Foreign			-	Buitenlands
Misc			-	Overig
Nouns			-	Zelfstandig naamwoorden
Verbs			-	Werkwoorden



