AnimalGroups			-	DierGroepen
Animals				-	Dieren
Animals_Badass			-	Dieren_Tof
Apparel				-	Kledij
Artworks			-	Kunststukjes
Bodyparts			-	Lichaamsdelen
BusinessTypes			-	Zakenlui
Colors				-	Kleuren
Colors_Badass			-	Kleuren_Tof
Communities			-	Gemeenschappen
Concepts_Angsty			-	Concepten_Angstig
Concepts_Badass			-	Concepten_Tof
Concepts_Positive		-	Concepten_Positief
Enemies				-	Vijanden
Games				-	Spellen
Gore				-	Ranzigheid
Groupnames			-	Groepsnamen
Mechanoid			-	Mechanoid
NaturalObject			-	NatuurObject
People_Allies			-	Mensen_Partners
People_Badass			-	Mensen_Tof
People_Family			-	Mensen_Familie
People_Jobs			-	Mensen_Banen
PersonalCharacteristics		-	PersoonlijkeEigenschappen
PoliticalUnions_Outlander	-	PolitiekeLigas_Buitenstaander
PoliticalUnions_Tribal		-	PolitiekeLigas_Stamgasten
Stories				-	Verhalen
TalkTopics_Heavy		-	PraatOnderwerpen_Zwaar
TalkTopics_Light		-	PraatOnderwerpen_Licht
TerrainFeatures			-	TerreinEigenschappen
TreeTypes			-	BoomSoorten
Vegetables			-	Groenten
Weapons				-	Wapens


// Vegetables - Groenten UNMODIFIED
// TreeTypes - BoomSoorten UNMODIFIED
