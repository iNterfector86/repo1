Angsty				-	Angstig
Badass				-	Groovy
CompassDirections		-	KompasRichtingen
Curious				-	Nieuwsgierig
Friendly			-	Vriendelijke
Large				-	Groot
Natural				-	Natuurlijk
PoliticalUnions			-	PolitiekeLigas
